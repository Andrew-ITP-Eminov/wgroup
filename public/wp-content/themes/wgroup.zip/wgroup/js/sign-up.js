document.querySelector('.footer_form .submit-wrapper input').value = "Get started";

